# 中创校园安全卫士

基于智慧校徽和智慧学生证的校园安全管理平台，为中小学生提供全方位的安全保护。

## 功能特点

- 🛡️ 防溺水、防走失、防霸凌
- 📱 响应式设计，适配手机、平板、桌面端
- 🔄 交互式三级导航
- 🖼️ 图片点击放大查看
- 📋 用户满意度调查问卷
- 🏢 完整的公司和产品信息展示

## 技术栈

- React 18
- Vite
- Tailwind CSS
- Lucide React Icons

## 本地开发

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build
```

## 部署到GitHub Pages

1. Fork或克隆此仓库到您的GitHub账户
2. 在仓库设置中启用GitHub Pages
3. 选择"GitHub Actions"作为部署源
4. 推送代码到main分支，GitHub Actions将自动构建和部署

## 部署到其他平台

### Vercel
1. 连接GitHub仓库到Vercel
2. 设置构建命令：`npm run build`
3. 设置输出目录：`dist`

### Netlify
1. 连接GitHub仓库到Netlify
2. 设置构建命令：`npm run build`
3. 设置发布目录：`dist`

### Cloudflare Pages
1. 连接GitHub仓库到Cloudflare Pages
2. 设置构建命令：`npm run build`
3. 设置输出目录：`dist`

## 公司信息

中创国建（海南）投资集团有限公司
- 地址：海南省海口市龙华区国贸大道56号
- 电话：0898-66668888 / 18819802668
- 邮箱：contact@campussafety.com

