import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  Shield, 
  MapPin, 
  Phone, 
  Users, 
  Activity, 
  Bell, 
  BookOpen, 
  CreditCard,
  Eye,
  Heart,
  Zap,
  CheckCircle,
  Star,
  Menu,
  X,
  Play,
  Download,
  Mail,
  MessageCircle
} from 'lucide-react'
import logoImage from './assets/logo_design.png'
import productImage from './assets/product-reference.png'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [surveyData, setSurveyData] = useState({})

  // 导航菜单项
  const menuItems = [
    { id: 'home', label: '首页', icon: Shield },
    { id: 'products', label: '产品中心', icon: BookOpen },
    { id: 'solutions', label: '解决方案', icon: Zap },
    { id: 'cases', label: '典型案例', icon: Star },
    { id: 'about', label: '关于我们', icon: Users }
  ]

  // 产品数据
  const products = [
    {
      id: 'badge',
      name: '智慧校徽',
      model: 'XH53WG-4L',
      image: productImage,
      description: '圆形设计，轻量化佩戴，多重定位技术',
      features: ['Φ50*8mm超薄设计', '22g轻量化', '一周超长待机', 'IP67防护等级'],
      specs: {
        size: 'Φ50*8mm',
        weight: '22g',
        battery: '一周待机',
        positioning: '北斗+GPS+WIFI+LBS+蓝牙+RFID',
        protection: 'IP67'
      }
    },
    {
      id: 'card',
      name: '智慧学生证',
      model: 'XH53WG-4',
      image: productImage,
      description: '卡片式设计，超长待机，全功能集成',
      features: ['98*56.5*8.96mm', '52g超轻重量', '两周超长待机', 'IP54防护等级'],
      specs: {
        size: '98*56.5*8.96mm',
        weight: '52g',
        battery: '两周待机',
        positioning: '北斗+GPS+WIFI+LBS+RFID+蓝牙',
        protection: 'IP54'
      }
    },
    {
      id: 'card-screen',
      name: '智慧学生证（有屏版）',
      model: 'XH53WG-4J',
      image: productImage,
      description: '带屏幕显示，支持红外测温，支付码功能',
      features: ['支持红外测温', '支付码亮码', '乘车码亮码', '支持超级SIM卡'],
      specs: {
        size: '98*57.5*8.96mm',
        weight: '56g',
        battery: '一周待机',
        positioning: '北斗+GPS+WIFI+LBS+RFID+蓝牙',
        protection: 'IP67'
      }
    }
  ]

  // 解决方案数据
  const solutions = [
    {
      id: 'school',
      title: '学校管理端',
      description: '全方位的校园安全管理解决方案',
      features: [
        { icon: Bell, title: '围栏预警', desc: '设置电子围栏，危险区域告警管理' },
        { icon: Phone, title: '通话管控', desc: '自主设置通话时间段，上课自动禁用' },
        { icon: Activity, title: '体质管理', desc: '统计分析学生运动量，提供体质管理依据' },
        { icon: CheckCircle, title: '自动考勤', desc: '进出学校自动考勤，生成报表和出勤率' },
        { icon: Eye, title: '在校状态', desc: '实时查看学生在校、考勤、佩戴状态' },
        { icon: MessageCircle, title: '家校沟通', desc: '多渠道沟通，提供阅读证明' },
        { icon: MapPin, title: '救助寻找', desc: '紧急事件时提供人工分析服务' },
        { icon: CreditCard, title: '校园一卡通', desc: '图书借阅、食堂消费、门禁等' }
      ]
    },
    {
      id: 'parent',
      title: '家长端',
      description: '让家长随时了解孩子的安全状况',
      features: [
        { icon: MessageCircle, title: '家校沟通服务', desc: '接收作业通知，一键请假，沟通记录' },
        { icon: MapPin, title: '定位轨迹服务', desc: '实时定位，查看轨迹，自定义围栏' },
        { icon: Phone, title: '电话沟通', desc: '学校允许时间段内拨打接听电话' },
        { icon: Bell, title: '公共预警', desc: '考勤信息，公共围栏预警提醒' }
      ]
    },
    {
      id: 'education',
      title: '教育局端',
      description: '区域性教育安全管理平台',
      features: [
        { icon: Users, title: '集团管理', desc: '接入上级集团、管理局组建一体化平台' },
        { icon: Activity, title: '数据统计', desc: '区域内学校安全数据统计分析' },
        { icon: Bell, title: '预警管理', desc: '区域性安全预警和应急响应' },
        { icon: BookOpen, title: '资源推广', desc: '推广教育资源，查看学生成绩' }
      ]
    }
  ]

  // 典型案例数据
  const cases = [
    {
      title: '兰州市安宁区',
      subtitle: '运营商免费投建',
      description: '从2017年开始，安宁区22所小学2万余名学生全部佩戴智慧校徽产品，教育局、学校、家长在使用期间给予了良好的反馈，至今稳定运行。',
      stats: [
        { label: '覆盖学校', value: '22所' },
        { label: '服务学生', value: '2万+' },
        { label: '运行时间', value: '7年+' },
        { label: '满意度', value: '98%' }
      ],
      image: productImage
    }
  ]

  // 滚动到指定部分
  const scrollToSection = (sectionId) => {
    setActiveSection(sectionId)
    setMobileMenuOpen(false)
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  // 处理调查问卷提交
  const handleSurveySubmit = (e) => {
    e.preventDefault()
    console.log('调查问卷数据:', surveyData)
    alert('感谢您的反馈！我们会认真考虑您的建议。')
    setSurveyData({})
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* 导航栏 */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-b border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <img src={logoImage} alt="中创校园安全卫士" className="h-10 w-10" />
              <span className="text-xl font-bold text-gray-900">中创校园安全卫士</span>
            </div>

            {/* 桌面端菜单 */}
            <div className="hidden md:flex items-center space-x-8">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeSection === item.id
                      ? 'text-blue-600 bg-blue-50'
                      : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            {/* 移动端菜单按钮 */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-md text-gray-700 hover:text-blue-600 hover:bg-gray-50"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* 移动端菜单 */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`flex items-center space-x-2 w-full px-4 py-3 text-left text-sm font-medium transition-colors ${
                    activeSection === item.id
                      ? 'text-blue-600 bg-blue-50'
                      : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* 主要内容 */}
      <main className="pt-16">
        {/* 首页部分 */}
        <section id="home" className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                中创校园安全卫士
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
                防溺水 · 防走失 · 防霸凌
              </p>
              <p className="text-lg text-gray-500 mb-12 max-w-4xl mx-auto">
                基于智慧校徽和智慧学生证的校园安全管理平台，为中小学生提供全方位的安全保护，
                让家长放心，让学校安心，让孩子开心。
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => scrollToSection('products')}
                >
                  了解产品
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={() => scrollToSection('solutions')}
                >
                  查看方案
                </Button>
              </div>
            </div>

            {/* 核心优势 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <Card className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <CardTitle>安全可靠</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    教育部认证推荐解决方案，中央电教馆数字化校园认证，安全可靠有保障
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Zap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <CardTitle>技术先进</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    北斗+GPS+WIFI+LBS+蓝牙+RFID多重定位，精准度高，覆盖范围广
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Heart className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <CardTitle>贴心服务</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    24小时全天候监护，家校沟通无障碍，让关爱无处不在
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* 安全问题统计 */}
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
                中小学生安全现状
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600 mb-2">5.7万</div>
                  <div className="text-sm text-gray-600">全国每年溺亡人数</div>
                  <div className="text-xs text-gray-500 mt-1">中小学生占比25.6%</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600 mb-2">32.4%</div>
                  <div className="text-sm text-gray-600">校园欺凌发生率</div>
                  <div className="text-xs text-gray-500 mt-1">弱势群体更易受欺凌</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600 mb-2">4801条</div>
                  <div className="text-sm text-gray-600">儿童走失信息</div>
                  <div className="text-xs text-gray-500 mt-1">2016-2021年五年间</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">2000元</div>
                  <div className="text-sm text-gray-600">电话手表售价</div>
                  <div className="text-xs text-gray-500 mt-1">造成学生攀比负担</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 产品中心部分 */}
        <section id="products" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                产品中心
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                专为校园安全设计的智能设备，轻量化佩戴，功能强大，安全可靠
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <Card key={product.id} className="hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="relative">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-48 object-cover rounded-lg mb-4 cursor-pointer"
                        onClick={() => setSelectedProduct(product)}
                      />
                      <Badge className="absolute top-2 right-2 bg-blue-600">
                        {product.model}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl">{product.name}</CardTitle>
                    <CardDescription>{product.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      {product.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span className="text-sm text-gray-600">{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button 
                      className="w-full"
                      onClick={() => setSelectedProduct(product)}
                    >
                      查看详情
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* 解决方案部分 */}
        <section id="solutions" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                解决方案
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                针对不同用户群体的专业解决方案，满足学校、家长、教育局的不同需求
              </p>
            </div>

            <Tabs defaultValue="school" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                {solutions.map((solution) => (
                  <TabsTrigger key={solution.id} value={solution.id}>
                    {solution.title}
                  </TabsTrigger>
                ))}
              </TabsList>

              {solutions.map((solution) => (
                <TabsContent key={solution.id} value={solution.id}>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-2xl">{solution.title}</CardTitle>
                      <CardDescription className="text-lg">
                        {solution.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {solution.features.map((feature, index) => (
                          <div key={index} className="text-center p-4 rounded-lg bg-gray-50 hover:bg-blue-50 transition-colors">
                            <feature.icon className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                            <h4 className="font-semibold text-gray-900 mb-2">{feature.title}</h4>
                            <p className="text-sm text-gray-600">{feature.desc}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* 典型案例部分 */}
        <section id="cases" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                典型案例
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                成功案例见证产品实力，用户好评证明服务质量
              </p>
            </div>

            {cases.map((caseItem, index) => (
              <Card key={index} className="mb-8 hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">
                        {caseItem.title}
                      </h3>
                      <p className="text-lg text-blue-600 mb-4">{caseItem.subtitle}</p>
                      <p className="text-gray-600 mb-6">{caseItem.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4">
                        {caseItem.stats.map((stat, statIndex) => (
                          <div key={statIndex} className="text-center p-4 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{stat.value}</div>
                            <div className="text-sm text-gray-600">{stat.label}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <img 
                        src={caseItem.image} 
                        alt={caseItem.title}
                        className="w-full max-w-md mx-auto rounded-lg shadow-lg cursor-pointer"
                        onClick={() => {
                          // 图片点击查看功能
                          window.open(caseItem.image, '_blank')
                        }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* 调查问卷 */}
            <Card className="mt-16">
              <CardHeader>
                <CardTitle className="text-2xl text-center">用户满意度调查</CardTitle>
                <CardDescription className="text-center">
                  您的反馈对我们非常重要，请花几分钟时间填写这份调查问卷
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSurveySubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name">姓名</Label>
                      <Input 
                        id="name"
                        value={surveyData.name || ''}
                        onChange={(e) => setSurveyData({...surveyData, name: e.target.value})}
                        placeholder="请输入您的姓名"
                      />
                    </div>
                    <div>
                      <Label htmlFor="role">身份</Label>
                      <Select 
                        value={surveyData.role || ''}
                        onValueChange={(value) => setSurveyData({...surveyData, role: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="请选择您的身份" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="parent">家长</SelectItem>
                          <SelectItem value="teacher">教师</SelectItem>
                          <SelectItem value="admin">学校管理员</SelectItem>
                          <SelectItem value="education">教育局工作人员</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="satisfaction">产品满意度</Label>
                    <Select 
                      value={surveyData.satisfaction || ''}
                      onValueChange={(value) => setSurveyData({...surveyData, satisfaction: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="请选择满意度" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">非常满意</SelectItem>
                        <SelectItem value="4">满意</SelectItem>
                        <SelectItem value="3">一般</SelectItem>
                        <SelectItem value="2">不满意</SelectItem>
                        <SelectItem value="1">非常不满意</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="feedback">意见建议</Label>
                    <Textarea 
                      id="feedback"
                      value={surveyData.feedback || ''}
                      onChange={(e) => setSurveyData({...surveyData, feedback: e.target.value})}
                      placeholder="请分享您的使用体验和建议"
                      rows={4}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full">
                    提交调查问卷
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* 关于我们部分 */}
        <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                关于我们
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                中创国建（海南）投资集团有限公司，专注于校园安全管理解决方案
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">
                  专业的校园安全服务商
                </h3>
                <div className="space-y-4 text-gray-600">
                  <p>
                    中创国建（海南）投资集团有限公司是一家专注于校园安全管理的高新技术企业，
                    致力于为中小学校提供全方位的安全管理解决方案。
                  </p>
                  <p>
                    我们的产品获得了教育部认证推荐，中央电教馆数字化校园认证，
                    在全国多个地区成功部署，服务数万名学生。
                  </p>
                  <p>
                    公司秉承"让每个孩子都能安全成长"的使命，不断创新技术，
                    优化产品，为构建安全校园贡献力量。
                  </p>
                </div>
                
                <div className="mt-8 space-y-4">
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-700">海南省海口市龙华区国贸大道56号</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-700">0898-66668888 / 18819802668</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-700">contact@campussafety.com</span>
                  </div>
                </div>
              </div>
              
              <div className="text-center">
                <img 
                  src={logoImage} 
                  alt="公司Logo"
                  className="w-64 h-64 mx-auto mb-6"
                />
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-4 bg-white rounded-lg shadow">
                    <div className="text-2xl font-bold text-blue-600">7+</div>
                    <div className="text-sm text-gray-600">年行业经验</div>
                  </div>
                  <div className="p-4 bg-white rounded-lg shadow">
                    <div className="text-2xl font-bold text-blue-600">100+</div>
                    <div className="text-sm text-gray-600">合作学校</div>
                  </div>
                  <div className="p-4 bg-white rounded-lg shadow">
                    <div className="text-2xl font-bold text-blue-600">5万+</div>
                    <div className="text-sm text-gray-600">服务学生</div>
                  </div>
                  <div className="p-4 bg-white rounded-lg shadow">
                    <div className="text-2xl font-bold text-blue-600">98%</div>
                    <div className="text-sm text-gray-600">客户满意度</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img src={logoImage} alt="中创校园安全卫士" className="h-8 w-8" />
                <span className="text-lg font-bold">中创校园安全卫士</span>
              </div>
              <p className="text-gray-400 text-sm">
                专业的校园安全管理解决方案提供商
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">产品中心</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>智慧校徽</li>
                <li>智慧学生证</li>
                <li>智慧学生证（有屏版）</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">解决方案</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>学校管理端</li>
                <li>家长端</li>
                <li>教育局端</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">联系我们</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>电话：0898-66668888</li>
                <li>邮箱：contact@campussafety.com</li>
                <li>地址：海南省海口市龙华区国贸大道56号</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 中创国建（海南）投资集团有限公司. 保留所有权利.</p>
          </div>
        </div>
      </footer>

      {/* 产品详情弹窗 */}
      <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedProduct && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedProduct.name}</DialogTitle>
                <DialogDescription>
                  型号：{selectedProduct.model}
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <img 
                    src={selectedProduct.image} 
                    alt={selectedProduct.name}
                    className="w-full rounded-lg shadow-lg"
                  />
                </div>
                
                <div>
                  <h4 className="font-semibold text-lg mb-4">产品特点</h4>
                  <div className="space-y-3 mb-6">
                    {selectedProduct.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <h4 className="font-semibold text-lg mb-4">技术参数</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">尺寸：</span>
                      <span>{selectedProduct.specs.size}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">重量：</span>
                      <span>{selectedProduct.specs.weight}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">待机时间：</span>
                      <span>{selectedProduct.specs.battery}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">定位方式：</span>
                      <span>{selectedProduct.specs.positioning}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">防护等级：</span>
                      <span>{selectedProduct.specs.protection}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-4 mt-6">
                <Button className="flex-1">
                  <Download className="h-4 w-4 mr-2" />
                  下载产品手册
                </Button>
                <Button variant="outline" className="flex-1">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  联系销售
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default App

