# 🚀 分步骤部署指南 - 中创校园安全卫士

## 📋 部署前准备清单

✅ 项目文件已准备完成  
✅ 构建版本已生成  
✅ 配置文件已优化  
✅ 部署指南已创建  

## 🎯 推荐部署方案：GitHub Pages

### 为什么选择GitHub Pages？
- ✅ 完全免费
- ✅ 永久稳定
- ✅ 全球CDN加速
- ✅ 自动HTTPS
- ✅ 简单易用

---

## 📝 详细操作步骤

### 第一步：注册GitHub账户
1. 访问 https://github.com
2. 点击右上角 "Sign up"
3. 填写用户名、邮箱、密码
4. 验证邮箱地址

### 第二步：创建新仓库
1. 登录GitHub后，点击右上角 "+" 
2. 选择 "New repository"
3. 仓库名称填写：`campus-safety-guardian`
4. 描述填写：`中创校园安全卫士 - 智慧校园安全管理平台`
5. 选择 "Public"（公开）
6. 勾选 "Add a README file"
7. 点击 "Create repository"

### 第三步：上传项目文件
1. 下载我提供的项目压缩包
2. 解压到本地文件夹
3. 在GitHub仓库页面，点击 "uploading an existing file"
4. 将以下文件夹和文件拖拽到页面：
   ```
   📁 src/              (源代码)
   📁 public/           (静态资源)
   📁 .github/          (自动部署配置)
   📄 package.json      (项目配置)
   📄 vite.config.js    (构建配置)
   📄 index.html        (入口文件)
   📄 README.md         (项目说明)
   📄 vercel.json       (Vercel配置)
   ```
5. 在底部填写提交信息："Initial commit - 中创校园安全卫士网站"
6. 点击 "Commit changes"

### 第四步：启用GitHub Pages
1. 在仓库页面，点击顶部的 "Settings"
2. 在左侧菜单中找到 "Pages"
3. 在 "Source" 部分选择 "GitHub Actions"
4. 页面会显示 "GitHub Pages will be built and deployed by GitHub Actions"

### 第五步：等待自动部署
1. 点击仓库顶部的 "Actions" 标签
2. 您会看到一个正在运行的工作流
3. 等待绿色的 ✅ 标记出现（约2-3分钟）
4. 部署完成后，返回 "Settings" → "Pages"
5. 您会看到网站地址：`https://您的用户名.github.io/campus-safety-guardian`

---

## 🌟 替代方案：Vercel（更快）

如果您想要更快的部署：

### Vercel部署步骤
1. 访问 https://vercel.com
2. 点击 "Sign up" → "Continue with GitHub"
3. 授权Vercel访问您的GitHub
4. 点击 "New Project"
5. 选择 `campus-safety-guardian` 仓库
6. 点击 "Import"
7. 保持默认设置，点击 "Deploy"
8. 等待1-2分钟，获得域名：`https://campus-safety-guardian.vercel.app`

---

## 🔧 部署后配置

### 更新package.json中的homepage
部署完成后，需要更新一个配置：
1. 在GitHub仓库中找到 `package.json` 文件
2. 点击编辑（铅笔图标）
3. 将第6行的 `"homepage": "https://USERNAME.github.io/campus-safety-guardian",` 
4. 改为：`"homepage": "https://您的实际用户名.github.io/campus-safety-guardian",`
5. 提交更改

---

## ✅ 验证部署结果

部署完成后，您的网站将具备：
- 🌐 永久域名访问
- 📱 完美移动端支持
- 🔒 HTTPS安全连接
- ⚡ 全球CDN加速
- 🔄 自动更新部署

---

## 🆘 常见问题解决

### Q: Actions部署失败？
**解决方案：**
1. 检查所有文件是否正确上传
2. 确保仓库是Public
3. 查看Actions页面的错误日志

### Q: 网站显示404？
**解决方案：**
1. 确认Pages设置正确
2. 等待几分钟让DNS生效
3. 检查homepage配置

### Q: 样式显示异常？
**解决方案：**
1. 更新package.json中的homepage字段
2. 重新触发部署

---

## 📞 需要帮助？

如果在部署过程中遇到任何问题，请告诉我具体的错误信息，我会帮您解决！

**预计部署时间：5-10分钟**  
**预计网站访问速度：全球<2秒**

